Note to translators and editors:

These are the error pages displayed in the HTTP proxy,
with the HTTP headers prepended.

All files in this directory must be DOS formatted with \r\n line endings,
so the HTTP header lines are standards-compliant. Thank you.
